package com.example.mindmoving.retrofit.models

data class LoginRequest(
    val email: String,
    val password: String)
