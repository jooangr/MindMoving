package com.example.mindmoving.retrofit.models

data class ActualizarUsuarioRequest(
    val username: String?,
    val email: String?,
    val password: String?
)
