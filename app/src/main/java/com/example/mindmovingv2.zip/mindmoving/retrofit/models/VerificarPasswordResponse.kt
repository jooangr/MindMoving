package com.example.mindmoving.retrofit.models

data class VerificarPasswordResponse(
    val success: Boolean,
    val message: String
)