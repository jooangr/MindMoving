package com.example.mindmoving.retrofit.models

data class VerificarPasswordRequest(
    val password: String
)
