package com.example.mindmoving.views.calibracion.guiada

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

@Composable
fun FaseParpadeoScreen( navController: NavHostController){


}