package com.example.mindmoving.retrofit.models.login_register

data class LoginRequest(
    val identifier: String,
    val password: String
)
