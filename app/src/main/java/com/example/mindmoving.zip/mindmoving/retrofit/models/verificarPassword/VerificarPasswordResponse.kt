package com.example.mindmoving.retrofit.models.verificarPassword

data class VerificarPasswordResponse(
    val success: Boolean,
    val message: String
)