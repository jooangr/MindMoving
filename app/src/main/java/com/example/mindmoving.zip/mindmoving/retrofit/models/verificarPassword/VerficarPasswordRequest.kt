package com.example.mindmoving.retrofit.models.verificarPassword

data class VerificarPasswordRequest(
    val password: String
)
