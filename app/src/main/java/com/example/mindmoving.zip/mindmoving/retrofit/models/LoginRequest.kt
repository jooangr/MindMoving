package com.example.mindmoving.retrofit.models

data class LoginRequest(
    val identifier: String,
    val password: String
)
