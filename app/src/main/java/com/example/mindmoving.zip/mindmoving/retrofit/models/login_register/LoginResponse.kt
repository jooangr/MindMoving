package com.example.mindmoving.retrofit.models.login_register

data class LoginResponse(
    val message: String,
    val userId: String)
