package com.example.mindmoving.retrofit.models

data class UsuarioLogin(
    val id: String,
    val username: String,
    val email: String
)