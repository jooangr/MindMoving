package com.example.mindmoving.retrofit.models

data class RegisterRequest(
    val username: String,
    val email: String,
    val password: String
)
