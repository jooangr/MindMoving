package com.example.mindmoving.retrofit.models.user

data class UsuarioLogin(
    val id: String,
    val username: String,
    val email: String
)