package com.example.mindmoving.retrofit.models

data class UsuarioResponse(
    val _id: String,
    val username: String,
    val email: String
)
