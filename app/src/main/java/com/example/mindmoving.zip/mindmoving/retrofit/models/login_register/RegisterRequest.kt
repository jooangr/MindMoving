package com.example.mindmoving.retrofit.models.login_register

data class RegisterRequest(
    val username: String,
    val email: String,
    val password: String
)
