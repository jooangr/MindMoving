package com.example.mindmoving.retrofit.models.user

data class UsuarioResponse(
    val _id: String,
    val username: String,
    val email: String
)
