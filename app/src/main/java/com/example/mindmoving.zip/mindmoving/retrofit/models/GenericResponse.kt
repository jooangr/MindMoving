package com.example.mindmoving.retrofit.models

data class GenericResponse(
    val success: Boolean? = null,
    val message: String
)
