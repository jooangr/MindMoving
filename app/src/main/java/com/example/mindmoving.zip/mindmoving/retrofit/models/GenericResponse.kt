package com.example.mindmoving.retrofit.models

data class GenericResponse(
    val success: Boolean,
    val message: String
)
