package com.example.mindmoving.retrofit.models

data class LoginResponse(
    val message: String,
    val userId: String)
