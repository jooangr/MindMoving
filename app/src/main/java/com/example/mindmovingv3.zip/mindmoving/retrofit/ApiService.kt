package com.example.mindmoving.retrofit

import com.example.mindmoving.retrofit.models.ActualizarUsuarioRequest
import com.example.mindmoving.retrofit.models.GenericResponse
import com.example.mindmoving.retrofit.models.LoginRequest
import com.example.mindmoving.retrofit.models.LoginResponse
import com.example.mindmoving.retrofit.models.PerfilCalibracionRequest
import com.example.mindmoving.retrofit.models.PerfilCalibracionResponse
import com.example.mindmoving.retrofit.models.RegisterRequest
import com.example.mindmoving.retrofit.models.SesionEEGRequest
import com.example.mindmoving.retrofit.models.UsuarioResponse
import com.example.mindmoving.retrofit.models.VerificarPasswordRequest
import com.example.mindmoving.retrofit.models.VerificarPasswordResponse
import com.example.mindmoving.retrofit.models.sesionesEGG.SesionEEGResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    // Validar credenciales en el login
    @POST("/api/login")
    suspend fun loginUser(@Body request: LoginRequest): Response<LoginResponse>

    // Registrarse por primera vez
    @POST("api/register")
    suspend fun registerUser(@Body request: RegisterRequest): Response<GenericResponse>

    // Guardar sesion de EEG
    @POST("/api/sesiones")
    suspend fun guardarSesion(@Body sesion: SesionEEGRequest): Response<GenericResponse>


    //Pedido por omar
    @POST("/api/sesiones")
    suspend fun crearSesionEEG(@Body sesion: SesionEEGRequest): Response<Void>

    //Recibir sesiones del BACKEND
    @GET("/api/sesiones/{userId}")
    suspend fun getSesiones(@Path("userId") userId: String): Response<List<SesionEEGResponse>>

    //Obtiene el perfil de calibración del usuario. Se usa tras login para personalizar la calibración y análisis EEG.
    @GET("/api/perfil/{usuarioId}")
    suspend fun getPerfil(@Path("usuarioId") usuarioId: String): Response<PerfilCalibracionResponse>

    @POST("/api/perfil")
    suspend fun crearPerfil(@Body perfil: PerfilCalibracionRequest): Response<GenericResponse>


    @POST("/api/verify-password")//login
    suspend fun verificarPasswordLogin(
        @Query("userId") userId: String,
        @Body password: String
    ): Response<VerificarPasswordResponse>

    @POST("/api/verificar-password/{id}")//editarpefil
    suspend fun verificarPasswordEditarPerfil(
        @Path("id") id: String,
        @Body request: VerificarPasswordRequest
    ): Response<GenericResponse>

    @PATCH("/api/update-user/{userId}")
    suspend fun actualizarUsuario(
        @Path("userId") userId: String,
        @Body request: ActualizarUsuarioRequest
    ): Response<GenericResponse>

    @GET("/api/users/{id}")
    suspend fun getUsuario(@Path("id") id: String): Response<UsuarioResponse>

}
