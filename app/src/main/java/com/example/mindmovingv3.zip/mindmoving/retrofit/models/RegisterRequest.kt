package com.example.mindmoving.retrofit.models

data class RegisterRequest(
    val email: String,
    val password: String,
    val username: String
)
