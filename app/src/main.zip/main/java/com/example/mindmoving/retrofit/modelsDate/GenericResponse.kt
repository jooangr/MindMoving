package com.example.mindmoving.retrofit.modelsDate

data class GenericResponse(
    val message: String
)
