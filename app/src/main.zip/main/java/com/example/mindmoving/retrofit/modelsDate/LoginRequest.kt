package com.example.mindmoving.retrofit.modelsDate

data class LoginRequest(
    val email: String,
    val password: String)
