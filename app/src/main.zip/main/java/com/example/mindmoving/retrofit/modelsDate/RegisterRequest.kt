package com.example.mindmoving.retrofit.modelsDate

data class RegisterRequest(val username: String, val email: String, val password: String)
