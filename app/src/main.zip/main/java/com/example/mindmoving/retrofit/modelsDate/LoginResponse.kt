package com.example.mindmoving.retrofit.modelsDate

data class LoginResponse(val message: String, val userId: String)
